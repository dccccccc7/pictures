package com.example.mes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class mesApplicationTests {

    @Test
    void contextLoads() {
    }

}
