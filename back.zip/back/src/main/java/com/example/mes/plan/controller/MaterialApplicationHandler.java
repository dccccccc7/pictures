package com.example.mes.plan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/MaterialApplication")
public class MaterialApplicationHandler {

	
	
}
