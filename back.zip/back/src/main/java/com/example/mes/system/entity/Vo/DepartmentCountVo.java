package com.example.mes.system.entity.Vo;

import lombok.Data;

@Data
public class DepartmentCountVo {
    private String department;
    private int count;
}
