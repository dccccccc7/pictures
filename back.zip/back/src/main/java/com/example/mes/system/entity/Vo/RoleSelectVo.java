package com.example.mes.system.entity.Vo;

public class RoleSelectVo {
    public String filter_role_name;
    public Integer pageSize;
    public Integer pageNum;
    public String sort;
    public String sortMethod;
}
